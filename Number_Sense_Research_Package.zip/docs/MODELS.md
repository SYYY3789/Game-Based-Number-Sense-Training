# Statistical models

For posttest and follow-up only, the primary outcome is

`Y_itj = X_itj beta + u_j + v_ij + e_itj`.

Class intercepts, child intercepts and occasion errors are independent centered Gaussian variables. The fixed design includes intercept, gamification, structured training, follow-up, both treatment-by-follow-up interactions, pretest mathematics, age, sex and vocabulary. Conventional teaching and posttest are reference levels. Baseline is a covariate and never a repeated outcome. Covariates are centered to improve conditioning.

For each class, `V = tau_class * J + tau_child * Z Z' + sigma2 * I`. Cholesky solves evaluate the profiled Gaussian likelihood. REML adds `log|X' V^-1 X|`. Variance components are optimized on a log scale with positive bounds. The covariance of beta is `(X' V^-1 X)^-1`. Convergence, variance components and optimizer messages are saved for every imputation. `test_mixed_gls_identity` independently checks the block implementation against a full-matrix generalized least-squares solve.

Posttest contrasts are G-C, S-C and G-S. Follow-up contrasts add the matching treatment-by-time term. Single-dataset Wald inference uses a t reference with 27 degrees of freedom (30 classes minus three arms). This is an approximate cluster-count choice, not Satterthwaite or Kenward-Roger. Pooled MI inference uses within- and between-imputation variance and a Barnard-Rubin-style finite complete-data degrees-of-freedom adjustment.

Secondary models adjust for their own baseline outcome and share the other covariates. All secondary outcomes are analyzed with available observations. Benjamini-Hochberg correction is applied across secondary endpoints separately for each visit and treatment contrast. Hedges g uses the pooled baseline SD for the corresponding two arms and a participant-count correction. Favorable g reverses the PAE sign.

Moderation adds standardized initial number sense and all two-way and three-way interactions with treatment and time. Simple effects are reported at -1, 0 and +1 SD. The Johnson-Neyman display is a grid over -2.5 to +2.5 SD in steps of 0.05; it is not an analytic threshold solver.
