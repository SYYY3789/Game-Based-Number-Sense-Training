# Mediation scope

Both gamification-versus-conventional and gamification-versus-structured contrasts are included. This addresses the manuscript's acknowledged mismatch between an active-control mechanism hypothesis and its reported conventional-control mechanism analysis.

The runnable analysis aggregates observed posttest scores and baseline controls to class means. Each mediator is regressed on assignment, baseline math, age and vocabulary. The outcome model includes all three mediators jointly plus the same treatment and controls. An indirect effect is a times b. The total indirect effect sums the three products. Class means receive equal weight, so this estimand differs from a child-weighted individual model.

Bootstrap samples resample classes with replacement within each treatment arm. Each resample refits the complete system. Percentile 95% intervals and bootstrap standard errors use 499 replicates by default; the extended profile uses 1,999. Original repeated class identifiers are irrelevant to the class-mean OLS calculations.

This analysis is not a multilevel structural-equation model, does not decompose participant-level within-class mediator associations and does not identify causal mediation. Posttest engagement and mathematics are measured contemporaneously. Unmeasured mediator-outcome confounding and ecological interpretation remain limitations. The implementation is provided as a transparent exploratory aggregate analysis rather than claiming equivalence to the manuscript's multilevel mediation model.
