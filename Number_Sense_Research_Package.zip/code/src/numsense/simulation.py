"""End-to-end synthetic generation. No original participant data are available."""
import numpy as np
import pandas as pd
from .constants import *
from .randomization import allocate
from .items import ordinal_items,line_items
from .scoring import score_items,pae,add_composites
from .attrition import visit_flags
from .sessions import simulate_sessions
from .io import write_csv,write_json
def simulate(root,cfg):
    rng=np.random.default_rng(cfg["seed"]);classes=allocate(rng);rows=[];latent={}
    for c in classes.itertuples():
        cls=rng.normal()
        for j in range(c.n_children):
            cid=f"{c.class_id}_P{j+1:02d}";ability=.38*cls+np.sqrt(1-.38**2)*rng.normal()
            latent[cid]=ability
            rows.append(dict(child_id=cid,class_id=c.class_id,arm=c.arm,
              age_months=np.clip(rng.normal(66.1,4.3),57,76),male=int(rng.random()<.512),
              only_child=int(rng.random()<.38),maternal_education=rng.choice(["HighSchool","College","Postgraduate"],p=[.21,.54,.25]),
              income_band=rng.choice(["Below5000","5000to10000","10000to20000","Above20000"],p=[.14,.38,.34,.14]),
              vocabulary=np.clip(52+7*ability+rng.normal(0,8),0,90),
              inhibition=np.clip(8.4+ability+rng.normal(0,2),0,16),
              working_memory=np.clip(6.1+.6*ability+rng.normal(0,1.7),0,12),
              flexibility=np.clip(7.8+.7*ability+rng.normal(0,2),0,16),
              home_numeracy=np.clip(3.4+.15*ability+rng.normal(0,.65),1,5),data_status="SYNTHETIC"))
    children=pd.DataFrame(rows);flags=visit_flags(children,rng)
    base=children.copy();base["ability"]=[latent[x] for x in base.child_id]
    panel=[];item_tables={k:[] for k in SCALES};lines=[]
    persistent={k:rng.normal(size=len(base)) for k in OUTCOMES}
    for wi,wave in enumerate(WAVES):
        frame=base[["child_id","class_id","arm"]].copy();frame["wave"]=wave;frame["week"]=[0,8,14][wi]
        observed=np.array([True if wi==0 else flags[x][wi-1] for x in base.child_id])
        frame["observed"]=observed.astype(int);frame["data_status"]="SYNTHETIC"
        for k in OUTCOMES:
            mu=np.array([MEANS[k][ARMS.index(a)][wi] for a in base.arm])
            ability=base.ability.to_numpy()*(-1 if k=="numberline_pae" else 1)
            target=mu+SD[k]*(.64*ability+.42*persistent[k]+.38*rng.normal(size=len(base)))
            if wi and k=="math":
                target-=np.where(base.arm=="Gamification",1.5,np.where(base.arm=="Structured",.6,0))*base.ability
            if k=="numberline_pae":
                targets,values=line_items(np.clip(target,1,45),rng)
                frame[k]=pae(targets,values)
                ir=frame[["child_id","class_id","arm","wave","observed","data_status"]].copy()
                for j in range(12):ir[f"target_{j+1:02d}"]=targets[j];ir[f"estimate_{j+1:02d}"]=np.where(observed,values[:,j],np.nan)
                lines.append(ir)
            else:
                values=ordinal_items(target,k,rng);frame[k]=score_items(values,k)
                ir=frame[["child_id","class_id","arm","wave","observed","data_status"]].copy()
                for j in range(values.shape[1]):ir[f"item_{j+1:02d}"]=np.where(observed,values[:,j],np.nan)
                item_tables[k].append(ir)
        panel.append(frame)
    truth=add_composites(pd.concat(panel,ignore_index=True))
    panel=truth.copy();panel.loc[panel.observed==0,OUTCOMES+["number_sense_z","far_transfer_sum"]]=np.nan
    sessions,attendance=simulate_sessions(children,classes,flags,rng)
    rates=attendance.groupby("child_id").attended.mean()
    children["attendance_rate"]=children.child_id.map(rates)
    children["posttest_complete"]=children.child_id.map(lambda x:int(flags[x][0]))
    children["followup_complete"]=children.child_id.map(lambda x:int(flags[x][1]))
    children["pp_eligible"]=((children.followup_complete==1)&((children.arm=="Conventional")|(children.attendance_rate>=cfg["pp_minimum_attendance"]))).astype(int)
    for name,df in [("children",children),("classes",classes),("assessments",panel),("session_fidelity",sessions),("attendance",attendance)]:
        write_csv(df,root/"data/raw"/(name+".csv"))
    write_csv(truth,root/"data/simulation_truth/complete_assessments.csv")
    for k,frames in item_tables.items():write_csv(pd.concat(frames,ignore_index=True),root/f"data/raw/items_{k}.csv")
    write_csv(pd.concat(lines,ignore_index=True),root/"data/raw/items_numberline.csv")
    # Independent second-rater perturbations on 20% of observed assessments.
    raters=[];obs=panel[panel.observed==1].sample(frac=.2,random_state=cfg["seed"])
    for k in MEDIATORS:
        a=obs[["child_id","wave"]].copy();a["scale"]=k;a["rater_one"]=obs[k]
        a["rater_two"]=np.clip(obs[k]+rng.normal(0,.35,len(obs)),1,5);a["data_status"]="SYNTHETIC";raters.append(a)
    write_csv(pd.concat(raters),root/"data/raw/dual_ratings.csv")
    manipulation=children[["child_id","class_id","arm","data_status"]].copy()
    for name,means in {"playfulness":[4.25,3.12,2.85],"narrative":[4.08,2.95,2.72],"progress":[4.32,3.05,2.68],"reward":[4.15,2.88,2.55],"choice":[3.95,3.18,3.05],"challenge":[3.85,3.62,3.45],"feedback":[4.28,3.75,3.22]}.items():
        manipulation[name]=np.clip([means[ARMS.index(x)] for x in children.arm]+rng.normal(0,.55,len(children)),1,5)
    write_csv(manipulation,root/"data/raw/manipulation.csv")
    write_json({"status":"SYNTHETIC","seed":cfg["seed"],"counts":len(children),"classes":len(classes),"item_scoring":"assumed; see SCORING.md","truth_use":"diagnostic only; never used by estimators"},root/"data/simulation_truth/generation_metadata.json")
    return children,panel
