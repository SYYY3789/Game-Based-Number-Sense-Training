"""Verify recorded SHA256 values. Run before altering delivered files."""
import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1];manifest=json.loads((root/"manifest.json").read_text());fail=[]
for record in manifest["files"]:
    p=root/record["path"]
    if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=record["sha256"]:fail.append(record["path"])
if fail:raise SystemExit("Changed or missing files:\n"+"\n".join(fail))
print(f"Verified {len(manifest['files'])} files")
