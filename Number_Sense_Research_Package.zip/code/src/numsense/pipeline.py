"""Orchestrate generation, validation, estimation and deliverable results."""
import json
import logging
import platform
import time
import numpy as np
import pandas as pd
import scipy
from .paths import ensure_dirs
from .io import write_csv,write_json
from .simulation import simulate
from .validation import validate
from .design import analysis_frame
from .descriptives import summarize,missing_table
from .reliability import alpha,icc_agreement,cluster_icc
from .constants import SCALES,OUTCOMES
from .imputation import impute_primary
from .primary import main_effects
from .secondary import secondary_effects
from .moderation import moderation
from .mediation import mediation
from .robustness import sensitivities,randomization_tests,delta_sensitivity
from .power import power_grid
from .figures import generate
from .report import write_report
def run(root,cfg,regenerate=False,extended=False,figures=True):
    ensure_dirs(root);t0=time.perf_counter()
    logging.basicConfig(level=logging.INFO,format="%(asctime)s %(message)s",handlers=[logging.StreamHandler(),logging.FileHandler(root/"results/logs/pipeline.log",mode="w")],force=True)
    log=logging.getLogger("numsense");log.info("Data status: SYNTHETIC")
    if regenerate or not (root/"data/raw/children.csv").exists():simulate(root,cfg)
    children=pd.read_csv(root/"data/raw/children.csv");panel=pd.read_csv(root/"data/raw/assessments.csv");classes=pd.read_csv(root/"data/raw/classes.csv");attendance=pd.read_csv(root/"data/raw/attendance.csv")
    checks=validate(children,panel,classes,attendance);frame=analysis_frame(children,panel);write_csv(frame,root/"data/derived/analysis_panel.csv")
    def table(name,d):write_csv(d,root/"results/tables"/(name+".csv"))
    table("data_validation",pd.DataFrame(checks));table("descriptive_statistics",summarize(panel));table("visit_missingness",missing_table(panel))
    table("baseline_correlations",panel[panel.wave=="Pretest"][OUTCOMES].corr().rename_axis("outcome").reset_index())
    quality=[]
    for scale in SCALES:
        items=pd.read_csv(root/f"data/raw/items_{scale}.csv")
        for wave,sub in items.groupby("wave"):
            quality.append(dict(scale=scale,wave=wave,cronbach_alpha=alpha(sub.filter(regex="^item_").to_numpy())))
    table("internal_consistency",pd.DataFrame(quality))
    ratings=pd.read_csv(root/"data/raw/dual_ratings.csv")
    table("interrater_reliability",pd.DataFrame([dict(scale=k,icc_A1=icc_agreement(g[["rater_one","rater_two"]]),n=len(g)) for k,g in ratings.groupby("scale")]))
    base=panel[panel.wave=="Pretest"]
    table("baseline_cluster_ICC",pd.DataFrame([dict(outcome=k,icc=cluster_icc(base[k],base.class_id)) for k in OUTCOMES]))
    fid=pd.read_csv(root/"data/raw/session_fidelity.csv")
    table("fidelity_summary",fid.groupby("arm").agg(sessions=("session","size"),duration_mean=("duration_min","mean"),fidelity_mean=("fidelity_pct","mean"),coverage_mean=("content_coverage_pct","mean")).reset_index())
    manipulation=pd.read_csv(root/"data/raw/manipulation.csv");table("manipulation_summary",manipulation.groupby("arm").mean(numeric_only=True).reset_index())
    log.info("Imputing primary scores: m=%s",cfg["imputations"])
    draws,trace=impute_primary(frame,cfg["imputations"],cfg["burn_in"],cfg["seed"]+100);table("imputation_trace",trace)
    imputed=[]
    for i,d in enumerate(draws,1):
        a=d[d.wave!="Pretest"][["child_id","wave","observed","math"]].copy();a["imputation"]=i;imputed.append(a)
    write_csv(pd.concat(imputed),root/"data/derived/primary_imputed_scores.csv")
    log.info("Fitting primary MI models")
    primary,diagnostics,coeff=main_effects(draws);table("primary_MI_contrasts",primary);table("primary_model_diagnostics",diagnostics);table("primary_coefficients_by_imputation",coeff)
    log.info("Fitting secondary and moderation models")
    sec,secdiag=secondary_effects(frame);table("secondary_contrasts",sec);table("secondary_model_diagnostics",secdiag)
    grid,terms,moddiag=moderation(frame);table("moderation_grid",grid);table("moderation_terms",terms);write_json(moddiag,root/"results/models/moderation.json")
    table("simple_slopes",grid[np.isclose(grid.baseline_z,-1)|np.isclose(grid.baseline_z,0)|np.isclose(grid.baseline_z,1)])
    log.info("Cluster bootstrap mediation and sensitivity analyses")
    med,boot=mediation(frame,cfg["bootstrap_replicates"],cfg["seed"]+200);table("mediation_paths",med);table("mediation_bootstrap_draws",boot)
    robust=sensitivities(frame);table("sensitivity_estimates",robust)
    tests,dist=randomization_tests(frame,cfg["permutation_replicates"],cfg["seed"]+300);table("cluster_randomization_tests",tests);table("resampling_distributions",dist)
    if extended:
        log.info("Extended delta sensitivity: five departures from MAR")
        table("delta_sensitivity",delta_sensitivity(draws))
    log.info("Monte Carlo power scenarios")
    table("power_grid",power_grid(cfg["power_replicates"],cfg["seed"]+400))
    # Keep literal reported values and generated estimates in distinct columns.
    compare=primary.copy();compare["manuscript_reported"]=compare.apply(lambda r:{("Posttest","G_vs_C"):5.68,("Posttest","S_vs_C"):2.52,("Posttest","G_vs_S"):3.16,("Followup","G_vs_C"):4.85,("Followup","G_vs_S"):2.87}.get((r.wave,r.comparison),np.nan),axis=1)
    compare["synthetic_minus_reported"]=compare.estimate-compare.manuscript_reported;table("reported_vs_synthetic",compare)
    if figures:log.info("Rendering ten figures");generate(root,panel,frame,cfg)
    write_report(root,primary,checks)
    success=bool(diagnostics.converged.all() and secdiag.converged.all() and moddiag["converged"] and robust.converged.all())
    write_json({"status":"completed","all_models_converged":success,"seconds":time.perf_counter()-t0,"config":cfg,"python":platform.python_version(),"numpy":np.__version__,"pandas":pd.__version__,"scipy":scipy.__version__,"extended":extended,"data_status":"SYNTHETIC"},root/"results/logs/run_metadata.json")
    log.info("Completed; all models converged: %s",success)
    if not success:raise RuntimeError("At least one model did not converge; inspect model diagnostics")
    return primary
