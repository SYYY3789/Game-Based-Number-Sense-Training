"""Synthetic attendance and intervention fidelity records."""
import numpy as np
import pandas as pd
from .constants import ARMS,PP
def simulate_sessions(children,classes,flags,rng):
    logs=[];attendance=[];eligible={}
    for arm,npp in zip(ARMS,PP):
        complete=children[(children.arm==arm)&children.child_id.map(lambda x: flags[x][1])]
        eligible.update({x:True for x in rng.choice(complete.child_id,npp,replace=False)})
    for row in classes.itertuples():
        if row.arm=="Conventional":continue
        for s in range(1,25):
            logs.append(dict(class_id=row.class_id,arm=row.arm,session=s,week=(s-1)//3+1,
              duration_min=np.clip(rng.normal(19.8,1.2),15,25),content_coverage_pct=np.clip(rng.normal(94,4),75,100),
              adherence_pct=np.clip(rng.normal(91,5),70,100),fidelity_pct=np.clip(rng.normal(93,4),70,100),
              feedback_events=int(rng.poisson(18)),scaffold_prompts=int(rng.poisson(7)),data_status="SYNTHETIC"))
    for c in children.itertuples():
        if c.arm=="Conventional":continue
        n=int(rng.integers(21,25)) if eligible.get(c.child_id) else int(rng.integers(13,20))
        selected=set(rng.choice(np.arange(1,25),n,replace=False))
        for s in range(1,25):
            attendance.append(dict(child_id=c.child_id,class_id=c.class_id,session=s,attended=int(s in selected),data_status="SYNTHETIC"))
    return pd.DataFrame(logs),pd.DataFrame(attendance)
