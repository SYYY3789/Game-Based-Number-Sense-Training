# Method coverage and differences

| Manuscript element | Delivered implementation | Boundary |
|---|---|---|
| Three arms and 30 randomized classes | Balanced synthetic class allocation | Original strata and allocation sequence unavailable |
| 594 children and three time points | Full child and item records with exact completion totals | All individual records simulated |
| Three-level repeated-outcome model | Gaussian nested class/child intercept REML | Assumes normal residuals and independent random effects |
| Twenty imputations | Bayesian joint-normal primary-outcome imputation | Secondary outcomes use available cases |
| Fractional model degrees of freedom | Cluster-count t and finite-df Rubin pooling | No Kenward-Roger or Satterthwaite implementation |
| Parallel multilevel mediation | Parallel class-mean mediation with stratified cluster bootstrap | Aggregate analysis; not multilevel SEM |
| Three-way moderation | Full treatment x time x standardized baseline design | Available cases; J-N interval uses a finite grid |
| FIML sensitivity | Observed-data Gaussian ML outcome model | Not joint FIML for an SEM |
| Missingness sensitivities | LOCF, PP and MI delta scenarios | Delta values are assumptions; no identified worst-case bound |
| Cluster-robust inference | CR1 OLS, class-label permutation and null wild-sign resampling | Not CR2 or studentized wild cluster bootstrap |
| Reliability | Item alpha, absolute-agreement ICC, baseline cluster ICC | Computed synthetic reliability differs from reported values |
| Power | Cluster-mean Monte Carlo grid | Does not reproduce manuscript's 87.3% power estimate |
| Data + code reference ZIP | Directory/module organization reference | Job-matching observations are unrelated and excluded |

The package is complete for the documented implemented workflow. A fully faithful empirical replication remains impossible without the original records, instrument scoring manual, allocation details and model specifications. No placeholder script is described as a completed method.
