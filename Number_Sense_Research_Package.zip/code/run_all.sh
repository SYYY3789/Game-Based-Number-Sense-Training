#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python code/run.py --extended
python -m unittest discover -s code/tests -v
