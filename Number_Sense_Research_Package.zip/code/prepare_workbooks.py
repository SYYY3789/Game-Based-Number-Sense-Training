"""Create typed workbook input matrices and a field dictionary from canonical CSV."""
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/"src"))
import pandas as pd
from numsense.constants import SCALES
from numsense.paths import ROOT
from numsense.io import write_csv
def frame_sheet(path,name):
    df=pd.read_csv(path,keep_default_na=True)
    matrix=[list(df.columns)]+json.loads(df.to_json(orient="values",double_precision=15))
    return dict(name=name,rows=matrix,source=str(path.relative_to(ROOT)))
def main():
    root=ROOT;rows=[]
    descriptions={"child_id":"Generated participant identifier; no real identity", "class_id":"Generated class identifier; randomization unit", "arm":"Randomized assignment: Gamification, Structured or Conventional", "wave":"Pretest, Posttest or Followup", "week":"Weeks since baseline: 0, 8 or 14", "observed":"1 if visit is observed, 0 if missing", "data_status":"SYNTHETIC for all generated individual records", "attendance_rate":"Attended intervention sessions divided by 24; blank for conventional arm", "pp_eligible":"Complete follow-up plus at least 80% intervention attendance; conventional uses completeness", "vocabulary":"Simulated scale-level picture vocabulary score; assumed 0 to 90", "numberline_pae":"Mean absolute number-line error / 20 x 100; lower is better", "number_sense_z":"Average baseline-standardized six-domain number sense score, reversing PAE", "far_transfer_sum":"Sum of pattern, measurement and spatial scores", "age_months":"Age in months, bounded 57 to 76", "male":"Synthetic binary sex coding: 1 male, 0 female", "only_child":"1 for only child, 0 otherwise"}
    for path in sorted((root/"data/raw").glob("*.csv")):
        df=pd.read_csv(path)
        for col in df:
            unit="category or identifier" if df[col].dtype==object else "count or score"
            description=descriptions.get(col,col.replace("_"," ").capitalize())
            if col.startswith("item_"):description="Synthetic ordinal item response; bounds depend on the scale";unit="item points"
            if col.startswith(("target_","estimate_")):unit="number-line units from 0 to 20"
            if col.endswith("_pct") or col=="numberline_pae":unit="percent from 0 to 100"
            if col=="duration_min":unit="minutes"
            rows.append(dict(file=path.name,field=col,type="text" if df[col].dtype==object else "numeric",unit=unit,description=description,missing_values=int(df[col].isna().sum()),status="SYNTHETIC"))
    dictionary=pd.DataFrame(rows);write_csv(dictionary,root/"data/derived/variable_dictionary.csv")
    scoring=pd.DataFrame([dict(scale=k,items=n,item_minimum=lo,item_maximum=hi,aggregation=how,rule_status="ASSUMED synthetic scoring",item_count_source="assumed" if k=="math" else "manuscript Table 3") for k,(n,lo,hi,how) in SCALES.items()])
    write_csv(scoring,root/"data/derived/scoring_rules.csv")
    provenance=[]
    for folder in ["raw","reported"]:
        for p in sorted((root/"data"/folder).glob("*.csv")):
            provenance.append(dict(file=str(p.relative_to(root)),status="SYNTHETIC" if folder=="raw" else "MANUSCRIPT REPORTED",source="Deterministic generator" if folder=="raw" else "manuscript(3).docx",rows=len(pd.read_csv(p))))
    write_csv(pd.DataFrame(provenance),root/"data/derived/source_registry.csv")
    panel=pd.read_csv(root/"data/raw/assessments.csv")
    write_csv(panel[["child_id","class_id","arm","wave","week","observed","data_status"]],root/"data/derived/visit_schedule.csv")
    books=[
      dict(file="01_Participants_and_Visits.xlsx",sheets=[frame_sheet(root/"data/raw/classes.csv","Classes"),frame_sheet(root/"data/raw/children.csv","Children"),frame_sheet(root/"data/derived/visit_schedule.csv","Visits")]),
      dict(file="02_Assessments_and_Items.xlsx",sheets=[frame_sheet(root/"data/raw/assessments.csv","Assessments")]+[frame_sheet(root/f"data/raw/items_{k}.csv","Items_"+k) for k in list(SCALES)+["numberline"]]),
      dict(file="03_Implementation_and_Ratings.xlsx",sheets=[frame_sheet(root/f"data/raw/{k}.csv",n) for k,n in [("session_fidelity","Session_Fidelity"),("attendance","Attendance"),("dual_ratings","Dual_Ratings"),("manipulation","Manipulation")]]),
      dict(file="04_Dictionary_and_Reported_Tables.xlsx",sheets=[frame_sheet(root/f"data/derived/{k}.csv",n) for k,n in [("variable_dictionary","Dictionary"),("scoring_rules","Scoring_Rules"),("source_registry","Provenance")]]+[frame_sheet(root/f"data/reported/table_{i:02d}.csv",f"Reported_Table_{i:02d}") for i in range(1,11)])]
    (root/"data/derived/workbook_inputs.json").write_text(json.dumps(books,ensure_ascii=False,allow_nan=False))
    print(f"Prepared {len(books)} workbooks, {sum(len(b['sheets']) for b in books)} sheets")
if __name__=="__main__":main()
