# Reproducibility and execution

Run the commands in README.md from the package root. Python entry points resolve paths from their own location, so they also work from another working directory. `run_all.sh` and `run_all.bat` run the extended pipeline followed by tests. The pipeline requires no network after dependencies are installed.

The default configuration uses twenty imputations, 499 mediation bootstrap samples, 999 resampling draws per contrast and 300 Monte Carlo draws per power scenario. `--extended` adds the five MI delta scenarios. `config/extended.json` increases numerical simulation effort. `config/smoke.json` is for rapid software checks and should not be used for final inference.

Raw data regeneration is deterministic for the recorded NumPy version and seed. Numerical optimizer outputs can vary slightly across platforms or BLAS libraries. Random streams for imputation, mediation, permutation and power are separated by explicit seed offsets. Avoid concurrent runs writing into the same results directory.

The Excel files are delivered data snapshots. The Python workflow uses CSV to avoid spreadsheet-engine differences. The optional workbook builder is included for the supported @oai/artifact-tool JavaScript environment. That authoring dependency is not required to run any statistical analysis or to read the delivered Excel workbooks.

Tests check fixed-effect GLS identities, multiple-imputation variance pooling, p-value adjustment, score reconstruction from items, bounds, primary and foreign keys, exact design counts, missingness separation and observed-value preservation. Results logs include package versions, configuration and model convergence. A checksum verification should precede any rerun because rerunning legitimately changes logs and generated output files.
