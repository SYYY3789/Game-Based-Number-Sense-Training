"""Tables derived only from the observed synthetic data."""
import pandas as pd
from .constants import OUTCOMES
def summarize(panel):
    long=panel.melt(id_vars=["arm","wave"],value_vars=OUTCOMES,var_name="outcome",value_name="score")
    return long.groupby(["outcome","wave","arm"]).score.agg(n="count",mean="mean",sd="std",minimum="min",maximum="max").reset_index()
def missing_table(panel):
    return panel.groupby(["arm","wave"])["observed"].agg(planned="size",observed="sum").assign(missing=lambda x:x.planned-x.observed,missing_rate=lambda x:1-x.observed/x.planned).reset_index()
