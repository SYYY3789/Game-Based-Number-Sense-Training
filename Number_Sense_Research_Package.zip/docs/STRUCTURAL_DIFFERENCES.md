# Source gaps and internal ambiguities

1. The manuscript says 36 classes were assessed and four declined, but 30 were randomized. The disposition of the remaining two classes is unspecified. The package does not invent a recruitment explanation.
2. Original randomization strata are not identified. The generator uses balanced class allocation without claiming to recover stratification.
3. Several item counts and reported means require partial credit or another scoring transformation. Item maxima and complete instrument rules are absent. Assumed synthetic rules are recorded in SCORING.md.
4. The composite mathematics item count and score range are not supplied. The package assumes thirty 0-to-3 items. Vocabulary and executive-function covariates are generated at scale level.
5. Reported subgroup means and adjusted coefficients are not algebraically interchangeable. Generated sample scores are not adjusted to force published significance or effect sizes.
6. A primary model table reports one intercept and treatment contrasts alongside longitudinal random effects, without a full treatment-by-time coefficient table. The implemented model follows the methods paragraph and includes these interactions explicitly.
7. The reported mediation contrast does not match the active-control H2 contrast. Both contrasts are computed here using the explicitly documented aggregate estimator.
8. PP in the conventional arm has no comparable training attendance measure. Conventional PP eligibility is defined by complete follow-up, while intervention arms additionally require at least 80% attendance.
9. Reliability, test-retest stability and rater agreement are distinct quantities. Synthetic alpha and rater ICC are labeled by statistic; the package does not reuse manuscript reliability numbers as computed findings.
