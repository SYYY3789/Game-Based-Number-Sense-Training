"""Human-readable file inventory and checksums."""
import hashlib
import json
from .io import write_json
def manifest(root):
    paths=sorted(p for p in root.rglob("*") if p.is_file() and "__pycache__" not in str(p) and p.name not in ["manifest.json","FILE_INDEX.md"])
    entries=[dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
    write_json({"data_status":"SYNTHETIC except data/reported","files":entries},root/"manifest.json")
    (root/"FILE_INDEX.md").write_text("# File index\n\n"+"\n".join(f"- `{e['path']}` ({e['bytes']:,} bytes)" for e in entries)+"\n")
    return len(entries)
