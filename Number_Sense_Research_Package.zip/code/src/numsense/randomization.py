"""Synthetic balanced class allocation; not the original allocation list."""
import numpy as np
import pandas as pd
from .constants import ARMS,SIZES
def allocate(rng):
    labels=np.repeat(ARMS,10);rng.shuffle(labels)
    rows=[]
    for arm,total in zip(ARMS,SIZES):
        ids=np.flatnonzero(labels==arm)
        sizes=np.full(10,total//10);sizes[:total%10]+=1
        rng.shuffle(sizes)
        for i,n in zip(ids,sizes):
            rows.append(dict(class_id=f"C{i+1:02d}",arm=arm,n_children=int(n),
                             data_status="SYNTHETIC",allocation_design="balanced class randomization"))
    return pd.DataFrame(rows).sort_values("class_id").reset_index(drop=True)
