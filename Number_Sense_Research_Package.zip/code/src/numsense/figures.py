"""Publication-resolution exploratory figures from computed synthetic results."""
from io import BytesIO
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from .constants import ARMS,OUTCOMES
PALETTE=["#35649C","#D68A3A","#627B6D"]
def generate(root,panel,frame,cfg):
    fonts={f.name for f in font_manager.fontManager.ttflist};font="Times New Roman" if "Times New Roman" in fonts else "Nimbus Roman"
    plt.rcParams.update({"font.family":font,"font.size":10,"axes.titleweight":"normal","axes.labelweight":"normal","axes.spines.top":False,"axes.spines.right":False})
    out=root/"results/figures";tables=root/"results/tables"
    def save(fig,name):
        fig.suptitle(fig._suptitle.get_text()+" | Synthetic data" if fig._suptitle else "Synthetic data",fontsize=13)
        fig.tight_layout(rect=[0,0,1,.96])
        for suffix in ["png","pdf"]:
            buf=BytesIO();fig.savefig(buf,format=suffix,dpi=cfg["figure_dpi"],bbox_inches="tight");(out/(name+"."+suffix)).write_bytes(buf.getvalue())
        plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(10,4));fig.suptitle("Participant flow and visit completion")
    for a,col in zip(ARMS,PALETTE):
        counts=[panel[(panel.arm==a)&(panel.wave==w)].observed.sum() for w in ["Pretest","Posttest","Followup"]]
        ax[0].plot([0,8,14],counts,"o-",label=a,color=col)
    ax[0].set(xlabel="Week",ylabel="Observed children");ax[0].legend()
    mat=panel.pivot(index="child_id",columns="week",values="observed");ax[1].imshow(mat,aspect="auto",cmap="Blues",vmin=0,vmax=1);ax[1].set(xticks=[0,1,2],xticklabels=["Pre","Post","Follow"],ylabel="Child")
    save(fig,"01_participant_flow")
    fig,axes=plt.subplots(2,3,figsize=(12,7));fig.suptitle("Observed longitudinal outcome profiles")
    for ax,k in zip(axes.flat,["math","counting","mapping","numberline_pae","behavioral","cognitive"]):
        for a,col in zip(ARMS,PALETTE):
            d=panel[panel.arm==a].groupby("week")[k].agg(["mean","std","count"]);ax.errorbar(d.index,d["mean"],yerr=1.96*d["std"]/np.sqrt(d["count"]),fmt="o-",color=col,label=a,capsize=3)
        ax.set(title=k.replace("_"," "),xlabel="Week",ylabel="Observed mean")
    axes[0,0].legend(fontsize=8);save(fig,"02_outcome_trajectories")
    fig,ax=plt.subplots(figsize=(9,8));fig.suptitle("Baseline correlations")
    corr=panel[panel.wave=="Pretest"][OUTCOMES].corr();im=ax.imshow(corr,cmap="RdBu_r",vmin=-1,vmax=1)
    ax.set(xticks=range(len(corr)),yticks=range(len(corr)),xticklabels=corr.columns,yticklabels=corr.columns);plt.setp(ax.get_xticklabels(),rotation=65,ha="right");fig.colorbar(im,ax=ax,shrink=.7);save(fig,"03_correlation_matrix")
    main=pd.read_csv(tables/"primary_MI_contrasts.csv");fig,axes=plt.subplots(1,2,figsize=(10,4));fig.suptitle("Adjusted primary contrasts with 95% intervals")
    for ax,w in zip(axes,["Posttest","Followup"]):
        d=main[main.wave==w];y=np.arange(len(d));ax.errorbar(d.estimate,y,xerr=[d.estimate-d.lower,d.upper-d.estimate],fmt="o",capsize=4,color=PALETTE[0]);ax.axvline(0,color="gray",ls="--");ax.set(yticks=y,yticklabels=d.comparison,title=w,xlabel="Mathematics points")
    save(fig,"04_primary_effects")
    sec=pd.read_csv(tables/"secondary_contrasts.csv");fig,axes=plt.subplots(1,2,figsize=(12,7));fig.suptitle("Secondary outcomes and favorable standardized effects")
    for ax,comp in zip(axes,["G_vs_C","G_vs_S"]):
        d=sec[(sec.wave=="Posttest")&(sec.comparison==comp)];ax.barh(d.outcome,d.favorable_g,color=[PALETTE[0] if q<.05 else "#B7C7D5" for q in d.q_value]);ax.axvline(0,color="gray");ax.set(title=comp,xlabel="Hedges g oriented toward improvement")
    save(fig,"05_secondary_effects")
    mod=pd.read_csv(tables/"moderation_grid.csv");fig,axes=plt.subplots(1,2,figsize=(11,4));fig.suptitle("Conditional effects across baseline number sense")
    for ax,w in zip(axes,["Posttest","Followup"]):
        for comp,col in zip(["G_vs_C","G_vs_S"],PALETTE):
            d=mod[(mod.wave==w)&(mod.comparison==comp)];ax.plot(d.baseline_z,d.estimate,color=col,label=comp);ax.fill_between(d.baseline_z,d.lower,d.upper,color=col,alpha=.15)
        ax.axhline(0,color="gray",ls="--");ax.set(title=w,xlabel="Baseline SD",ylabel="Conditional mathematics effect");ax.legend()
    save(fig,"06_moderation")
    med=pd.read_csv(tables/"mediation_paths.csv");fig,axes=plt.subplots(1,2,figsize=(11,4));fig.suptitle("Exploratory class-mean mediation")
    for ax,c in zip(axes,["G_vs_C","G_vs_S"]):
        d=med[(med.comparison==c)&med.path.str.startswith("indirect_")];y=np.arange(len(d));ax.errorbar(d.estimate,y,xerr=[d.estimate-d.lower,d.upper-d.estimate],fmt="o",capsize=4);ax.set(yticks=y,yticklabels=d.path.str.replace("indirect_",""),title=c,xlabel="Indirect effect with bootstrap interval");ax.axvline(0,color="gray",ls="--")
    save(fig,"07_mediation")
    robust=pd.read_csv(tables/"sensitivity_estimates.csv");fig,ax=plt.subplots(figsize=(9,5));fig.suptitle("Primary sensitivity analyses")
    d=robust[(robust.wave=="Posttest")&(robust.comparison=="G_vs_C")];y=np.arange(len(d));ax.errorbar(d.estimate,y,xerr=[d.estimate-d.lower,d.upper-d.estimate],fmt="o",capsize=4);ax.set(yticks=y,yticklabels=d.analysis,xlabel="Mathematics points");ax.axvline(0,color="gray",ls="--");save(fig,"08_sensitivity")
    trace=pd.read_csv(tables/"imputation_trace.csv");fig,axes=plt.subplots(1,2,figsize=(10,4));fig.suptitle("Imputation diagnostics")
    axes[0].plot(trace.iteration,trace.post_missing_mean,label="Posttest");axes[0].plot(trace.iteration,trace.follow_missing_mean,label="Followup");axes[0].axvline(cfg["burn_in"],ls="--",color="gray");axes[0].set(xlabel="Iteration",ylabel="Mean of imputed missing scores");axes[0].legend()
    axes[1].plot(trace.iteration,trace.residual_correlation);axes[1].set(xlabel="Iteration",ylabel="Residual post-follow correlation");save(fig,"09_imputation_diagnostics")
    power=pd.read_csv(tables/"power_grid.csv");fig,axes=plt.subplots(1,3,figsize=(12,4));fig.suptitle("Monte Carlo design sensitivity")
    for ax,icc in zip(axes,[.05,.15,.25]):
        for e,col in zip([.25,.4,.55],PALETTE):
            d=power[np.isclose(power.icc,icc)&np.isclose(power.standardized_effect,e)];ax.errorbar(d.classes_per_arm,d.power,yerr=1.96*d.mc_se,label=f"d = {e}",color=col,fmt="o-")
        ax.axhline(.8,color="gray",ls="--");ax.set(title=f"ICC = {icc}",xlabel="Classes per arm",ylabel="Estimated power",ylim=(0,1.05));ax.legend(fontsize=8)
    save(fig,"10_power")
    (out/"FIGURE_NOTES.md").write_text(f"# Figure notes\n\nAll figures use synthetic records. PNG resolution: {cfg['figure_dpi']} dpi. Vector PDF equivalents are supplied. Font: {font}; Times New Roman is used when installed, otherwise Nimbus Roman. Fonts are regular weight. Descriptive trajectory intervals treat children as independent and are descriptive only; primary inference uses clustered models. Dark secondary bars indicate BH-adjusted q below 0.05 and pale bars indicate q at least 0.05. The visit matrix uses dark blue for observed and white for missing visits. Mediation and moderation intervals do not establish causal mechanisms. Power intervals show Monte Carlo uncertainty.\n")
