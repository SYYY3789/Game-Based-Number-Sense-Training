#!/usr/bin/env python3
"""Run from any directory: python code/run.py --regenerate --extended."""
import os
for key in ["OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS"]:os.environ.setdefault(key,"1")
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/"src"))
from numsense.paths import ROOT
from numsense.pipeline import run
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",type=Path,default=ROOT/"config/default.json")
    parser.add_argument("--regenerate",action="store_true")
    parser.add_argument("--extended",action="store_true")
    parser.add_argument("--no-figures",action="store_true")
    args=parser.parse_args();run(ROOT,json.loads(args.config.read_text()),args.regenerate,args.extended,not args.no_figures)
if __name__=="__main__":main()
