"""Generate bounded ordinal items using a calibrated expected score.

Calibration changes item success probabilities, not realized sample means.
Scoring is performed from generated items in scoring.py.
"""
import numpy as np
from scipy.special import expit
from .constants import SCALES
def ordinal_items(target, scale, rng):
    n,low,high,method=SCALES[scale]
    total=np.asarray(target)*(n if method=="mean" else 1)
    p=np.clip((total/n-low)/(high-low),.005,.995)
    difficulty=np.linspace(-.7,.7,n)
    left=np.full(len(p),-12.);right=-left
    for _ in range(45):
        mid=(left+right)/2
        pm=expit(mid[:,None]-difficulty).mean(axis=1)
        left=np.where(pm<p,mid,left);right=np.where(pm>=p,mid,right)
    prob=expit(((left+right)/2)[:,None]-difficulty)
    return low+rng.binomial(high-low,prob)
def line_items(target_pae,rng):
    targets=np.linspace(1,19,12)
    err=np.asarray(target_pae)[:,None]/100*20*rng.lognormal(-.12,.49,(len(target_pae),12))
    signs=rng.choice([-1,1],size=err.shape)
    estimates=targets+signs*err
    # Reflect estimates across bounds; then clip unusually large tails.
    estimates=np.where(estimates<0,-estimates,estimates)
    estimates=np.where(estimates>20,40-estimates,estimates)
    return targets,np.clip(estimates,0,20)
