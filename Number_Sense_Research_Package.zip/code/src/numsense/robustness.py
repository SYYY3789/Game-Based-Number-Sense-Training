"""Sensitivity estimates and class-level randomization/wild bootstrap tests."""
import numpy as np
import pandas as pd
from .primary import fit_longitudinal
from .design import contrast,matrix
from .inference import estimate
from .cluster_ols import fit_cluster_ols
def sensitivities(frame):
    cases={"available_case_REML":frame.copy(),"available_case_ML":frame.copy(),"per_protocol":frame[frame.pp_eligible==1].copy()}
    locf=frame.copy();locf=locf.assign(wave_order=locf.wave.map({"Pretest":0,"Posttest":1,"Followup":2})).sort_values(["child_id","wave_order"])
    locf["math"]=locf.groupby("child_id").math.ffill();cases["LOCF"]=locf
    rows=[]
    for key,data in cases.items():
        f,names,d,x=fit_longitudinal(data,reml=key!="available_case_ML")
        for wave in ["Posttest","Followup"]:
            for comp in ["G_vs_C","S_vs_C","G_vs_S"]:
                r=estimate(f.beta,f.covariance,contrast(names,comp,wave));r.update(analysis=key,comparison=comp,wave=wave,n_observations=len(d),converged=f.converged);rows.append(r)
    d=frame[(frame.wave!="Pretest")&frame.math.notna()];x,names=matrix(d);b,v=fit_cluster_ols(d.math,x,d.class_id)
    for wave in ["Posttest","Followup"]:
        for comp in ["G_vs_C","S_vs_C","G_vs_S"]:
            r=estimate(b,v,contrast(names,comp,wave));r.update(analysis="OLS_CR1",comparison=comp,wave=wave,n_observations=len(d),converged=True);rows.append(r)
    return pd.DataFrame(rows)
def delta_sensitivity(draws):
    rows=[]
    # Each imputed missing score receives a treatment-specific departure from MAR.
    from .primary import main_effects
    for delta in [-6,-3,0,3,6]:
        changed=[]
        for d in draws:
            d=d.copy();ix=(d.observed==0)&(d.arm=="Gamification");d.loc[ix,"math"]+=delta;changed.append(d)
        results,_,_=main_effects(changed)
        results["delta_points"]=delta;rows.append(results)
    return pd.concat(rows,ignore_index=True)
def randomization_tests(frame,reps,seed):
    # Adjust using only baseline covariates, never treatment. Permute class labels.
    d=frame[(frame.wave=="Posttest")&frame.math.notna()].copy()
    x=np.column_stack([np.ones(len(d)),d[["baseline_math","age_months","male","vocabulary"]]])
    d["residual"]=d.math-x@np.linalg.lstsq(x,d.math,rcond=None)[0]
    cl=d.groupby(["class_id","arm"],as_index=False).residual.mean();rng=np.random.default_rng(seed);rows=[];distribution=[]
    for comp,a,b in [("G_vs_C","Gamification","Conventional"),("S_vs_C","Structured","Conventional"),("G_vs_S","Gamification","Structured")]:
        pair=cl[cl.arm.isin([a,b])];y=pair.residual.to_numpy();label=(pair.arm==a).to_numpy();obs=y[label].mean()-y[~label].mean();per=[];wild=[]
        centered=y-y.mean()
        for i in range(reps):
            shuffled=rng.permutation(label);per.append(y[shuffled].mean()-y[~shuffled].mean())
            yy=centered*rng.choice([-1,1],len(y));wild.append(yy[label].mean()-yy[~label].mean())
            distribution.append(dict(comparison=comp,replicate=i+1,permutation_effect=per[-1],wild_null_effect=wild[-1]))
        rows.append(dict(comparison=comp,observed_effect=obs,permutation_p=(1+sum(np.abs(per)>=abs(obs)))/(reps+1),wild_p=(1+sum(np.abs(wild)>=abs(obs)))/(reps+1),replicates=reps))
    return pd.DataFrame(rows),pd.DataFrame(distribution)
