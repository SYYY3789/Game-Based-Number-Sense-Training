"""Bayesian joint-normal imputation of primary post/follow-up scores.

Predictors: class fixed effects, age, sex, vocabulary, baseline math and
baseline number sense. Both outcomes are imputed jointly by data augmentation.
Class indicators carry assignment information. Outcomes are continuous
analysis scores, so imputed values are not rounded or clipped.
"""
import numpy as np
import pandas as pd
from scipy.stats import invwishart
def impute_primary(frame,m,burn,seed):
    d=frame.drop_duplicates("child_id").sort_values("child_id").copy()
    wide=frame.pivot(index="child_id",columns="wave",values="math").reindex(d.child_id)
    y=wide[["Posttest","Followup"]].to_numpy();missing=np.isnan(y)
    raw=d[["age_months","male","vocabulary","baseline_math","baseline_ns"]].to_numpy()
    raw=(raw-raw.mean(axis=0))/raw.std(axis=0,ddof=1)
    x=np.column_stack([np.ones(len(d)),pd.get_dummies(d.class_id,drop_first=True,dtype=float),raw])
    inv=np.linalg.inv(x.T@x);lx=np.linalg.cholesky(inv);rng=np.random.default_rng(seed)
    filled=y.copy()
    for j in range(2):filled[missing[:,j],j]=np.nanmean(y[:,j])
    draws=[];trace=[]
    for it in range(burn+m):
        bhat=inv@x.T@filled;resid=filled-x@bhat
        sigma=invwishart.rvs(df=len(d)-x.shape[1],scale=resid.T@resid,random_state=rng)
        coef=bhat+lx@rng.normal(size=(x.shape[1],2))@np.linalg.cholesky(sigma).T
        mu=x@coef
        for pattern in [(True,True),(True,False),(False,True)]:
            ix=np.flatnonzero(np.all(missing==pattern,axis=1));mi=np.flatnonzero(pattern);oi=np.flatnonzero(~np.array(pattern))
            if not len(ix):continue
            if not len(oi):
                cm=mu[ix];cv=sigma
            else:
                b=sigma[np.ix_(mi,oi)]@np.linalg.inv(sigma[np.ix_(oi,oi)])
                cm=mu[np.ix_(ix,mi)]+(y[np.ix_(ix,oi)]-mu[np.ix_(ix,oi)])@b.T
                cv=sigma[np.ix_(mi,mi)]-b@sigma[np.ix_(oi,mi)]
            filled[np.ix_(ix,mi)]=cm+rng.normal(size=(len(ix),len(mi)))@np.linalg.cholesky(cv).T
        trace.append(dict(iteration=it+1,retained=int(it>=burn),post_missing_mean=float(filled[missing[:,0],0].mean()),follow_missing_mean=float(filled[missing[:,1],1].mean()),residual_correlation=float(sigma[0,1]/np.sqrt(sigma[0,0]*sigma[1,1]))))
        if it>=burn:
            a=pd.DataFrame(filled,index=d.child_id,columns=["Posttest","Followup"])
            a=a.rename_axis("child_id").reset_index().melt(id_vars="child_id",var_name="wave",value_name="math_imputed")
            merged=frame.merge(a,on=["child_id","wave"],how="left",validate="one_to_one")
            merged["math"]=merged["math"].fillna(merged.math_imputed);merged=merged.drop(columns="math_imputed")
            draws.append(merged)
    return draws,pd.DataFrame(trace)
