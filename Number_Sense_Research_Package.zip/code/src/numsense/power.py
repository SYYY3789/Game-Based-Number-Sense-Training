"""Monte Carlo planning under explicit synthetic cluster-mean assumptions."""
import numpy as np
import pandas as pd
from scipy.stats import ttest_ind
def power_grid(reps,seed):
    rng=np.random.default_rng(seed);rows=[]
    for k in [8,10,15,20]:
        for icc in [.05,.15,.25]:
            for effect in [.25,.4,.55]:
                sd=np.sqrt(icc+(1-icc)/20);hits=0
                for _ in range(reps):
                    a=rng.normal(effect,sd,k);b=rng.normal(0,sd,k);hits+=ttest_ind(a,b,equal_var=False).pvalue<.05
                p=hits/reps;rows.append(dict(classes_per_arm=k,children_per_class=20,icc=icc,standardized_effect=effect,power=p,mc_se=np.sqrt(p*(1-p)/reps),replicates=reps,assumption="independent normal class means; two-arm Welch test"))
    return pd.DataFrame(rows)
