"""Linear contrasts, small-cluster t reference, Rubin pooling, BH correction."""
import numpy as np
from scipy.stats import t
def estimate(beta,cov,c,df=27):
    b=float(c@beta);v=max(float(c@cov@c),0);se=np.sqrt(v);crit=t.ppf(.975,df)
    return dict(estimate=b,se=se,df=float(df),lower=b-crit*se,upper=b+crit*se,p_value=float(2*t.sf(abs(b/se),df)) if se else float(b==0))
def rubin(estimates,variances,complete_df=27):
    q=np.asarray(estimates);u=np.asarray(variances);m=len(q)
    mean=q.mean();within=u.mean();between=q.var(ddof=1) if m>1 else 0
    total=within+(1+1/m)*between
    lam=(1+1/m)*between/total if total>0 else 0
    old=(m-1)/max(lam**2,1e-15)
    obs=(complete_df+1)/(complete_df+3)*complete_df*(1-lam)
    df=1/(1/old+1/max(obs,1e-8)) if m>1 else complete_df
    out=estimate(np.array([mean]),np.array([[total]]),np.array([1]),df)
    out.update(within_variance=within,between_variance=between,missing_information=lam,m=m)
    return out
def bh(p):
    p=np.asarray(p);o=np.argsort(p);q=np.empty(len(p));q[o]=np.minimum.accumulate((p[o]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]
    return np.minimum(q,1)
def hedges_g(effect,sd,n1,n0):
    df=n1+n0-2
    return (1-3/(4*df-1))*effect/sd
