# Data model and joins

`classes.class_id` is the class primary key. `children.child_id` is the child primary key and references one class and one arm. Assessment and item tables have the composite key `(child_id, wave)`. They contain all three planned visits, including blank unobserved visits. Attendance has key `(child_id, session)`. Fidelity has key `(class_id, session)`. Only the two intervention arms have study training-session records. Dual ratings have key `(child_id, wave, scale)`.

Use `data/raw/assessments.csv` for observed scale-level scores, `items_*.csv` for item-level reconstruction, and `data/derived/analysis_panel.csv` for joined baseline covariates. `primary_imputed_scores.csv` adds an imputation identifier; each child has two primary outcome records per imputation. `observed` records whether that score was originally observed. Do not average completed scores before model fitting. Fit each completed dataset and pool estimates.

The complete pre-attrition values in simulation_truth are inaccessible to the estimator through the standard pipeline. They exist for future simulation diagnostics only. File checksums and a complete file inventory are stored at the package root.
