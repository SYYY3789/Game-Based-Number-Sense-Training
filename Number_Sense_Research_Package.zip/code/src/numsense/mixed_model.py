"""Gaussian nested random-intercept ML/REML without optional packages.

For each class V = tau_class J + tau_child Z Z' + sigma2 I.
Profile beta analytically; minimize log determinant plus residual quadratic.
REML adds log|X'V^-1 X|. Wald covariance treats estimated variance components
as fixed; this is not Kenward-Roger or Satterthwaite inference.
"""
from dataclasses import dataclass
import numpy as np
from scipy.linalg import cho_factor,cho_solve
from scipy.optimize import minimize
@dataclass
class Fit:
    beta: np.ndarray
    covariance: np.ndarray
    variances: np.ndarray
    converged: bool
    objective: float
    n: int
    rank: int
    message: str
    iterations: int
def fit_mixed(y,X,classes,children,reml=True):
    y=np.asarray(y,float);X=np.asarray(X,float)
    if len(y)<=X.shape[1] or np.linalg.matrix_rank(X)<X.shape[1]:raise ValueError("Rank-deficient or undersized fixed-effect design")
    classes=np.asarray(classes);children=np.asarray(children);blocks=[]
    for key in np.unique(classes):
        ix=np.flatnonzero(classes==key);ids=children[ix]
        blocks.append((y[ix],X[ix],np.equal.outer(ids,ids).astype(float),np.eye(len(ix)),np.ones((len(ix),len(ix)))))
    def evaluate(theta,details=False):
        vc,vp,ve=np.exp(theta);a=np.zeros((X.shape[1],X.shape[1]));b=np.zeros(X.shape[1]);q=0.;ld=0.
        for yy,xx,cc,ii,jj in blocks:
            v=vc*jj+vp*cc+ve*ii;fac=cho_factor(v,lower=True,check_finite=False)
            vx=cho_solve(fac,xx,check_finite=False);vy=cho_solve(fac,yy,check_finite=False)
            a+=xx.T@vx;b+=xx.T@vy;q+=yy@vy;ld+=2*np.log(np.diag(fac[0])).sum()
        fa=cho_factor(a,lower=True,check_finite=False);beta=cho_solve(fa,b,check_finite=False)
        objective=ld+q-b@beta+(2*np.log(np.diag(fa[0])).sum() if reml else 0)
        if details:return beta,cho_solve(fa,np.eye(len(beta))),objective
        return objective
    v=max(np.var(y),.01);start=np.log([v*.08,v*.42,v*.5])
    opt=minimize(evaluate,start,method="L-BFGS-B",bounds=[(-16,np.log(v*30))]*3,options={"maxiter":200,"ftol":1e-10})
    beta,cov,obj=evaluate(opt.x,True)
    return Fit(beta,cov,np.exp(opt.x),bool(opt.success),float(obj),len(y),X.shape[1],str(opt.message),int(opt.nit))
