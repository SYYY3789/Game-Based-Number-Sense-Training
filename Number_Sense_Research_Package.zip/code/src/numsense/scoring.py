"""Scoring functions used by both simulation and raw-data reconstruction."""
import numpy as np
from .constants import SCALES,NEAR,TRANSFER
def score_items(items,scale):
    return items.mean(axis=1) if SCALES[scale][3]=="mean" else items.sum(axis=1)
def pae(targets,estimates,span=20):
    return 100*np.mean(np.abs(estimates-targets),axis=1)/span
def add_composites(panel):
    panel=panel.copy();base=panel[panel.wave=="Pretest"]
    z=[]
    for k in NEAR:
        direction=-1 if k=="numberline_pae" else 1
        z.append(direction*(panel[k]-base[k].mean())/base[k].std(ddof=1))
    panel["number_sense_z"]=np.mean(z,axis=0)
    panel["far_transfer_sum"]=panel[TRANSFER].sum(axis=1,min_count=3)
    return panel
