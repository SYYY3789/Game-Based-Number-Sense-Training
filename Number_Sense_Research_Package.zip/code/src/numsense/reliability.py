"""Cronbach alpha and two-way absolute-agreement single-rater ICC."""
import numpy as np
def alpha(items):
    x=np.asarray(items,float);x=x[np.isfinite(x).all(axis=1)];k=x.shape[1]
    return k/(k-1)*(1-x.var(axis=0,ddof=1).sum()/x.sum(axis=1).var(ddof=1))
def icc_agreement(ratings):
    x=np.asarray(ratings,float);n,k=x.shape;gm=x.mean();rm=x.mean(axis=1);cm=x.mean(axis=0)
    msr=k*np.sum((rm-gm)**2)/(n-1);msc=n*np.sum((cm-gm)**2)/(k-1)
    mse=np.sum((x-rm[:,None]-cm[None,:]+gm)**2)/((n-1)*(k-1))
    return (msr-mse)/(msr+(k-1)*mse+k*(msc-mse)/n)
def cluster_icc(values,classes):
    x=np.asarray(values);g=np.asarray(classes);unique=np.unique(g);ns=np.array([sum(g==c) for c in unique]);means=np.array([x[g==c].mean() for c in unique]);n=len(x);k=len(unique)
    msb=np.sum(ns*(means-x.mean())**2)/(k-1);msw=sum(np.sum((x[g==c]-mu)**2) for c,mu in zip(unique,means))/(n-k)
    n0=(n-np.sum(ns**2)/n)/(k-1)
    return (msb-msw)/(msb+(n0-1)*msw)
