"""Path helpers independent of the shell working directory."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
def ensure_dirs(root=ROOT):
    for p in ["data/raw", "data/derived", "data/simulation_truth", "data/excel", "results/tables", "results/figures", "results/logs", "results/models"]:
        (root / p).mkdir(parents=True, exist_ok=True)
    return root
