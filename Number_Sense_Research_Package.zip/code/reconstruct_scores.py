"""Reconstruct all scored outcomes from raw items and compare saved scores."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/"src"))
import numpy as np
import pandas as pd
from numsense.paths import ROOT
from numsense.constants import SCALES
from numsense.scoring import score_items,pae
from numsense.io import write_csv
rows=[]
for name in list(SCALES)+["numberline"]:
    d=pd.read_csv(ROOT/f"data/raw/items_{name}.csv");d=d[d.observed==1]
    if name=="numberline":score=pae(d.filter(regex="^target_").to_numpy(),d.filter(regex="^estimate_").to_numpy());name="numberline_pae"
    else:score=score_items(d.filter(regex="^item_").to_numpy(),name)
    out=d[["child_id","wave"]].copy();out["outcome"]=name;out["reconstructed_score"]=score;rows.append(out)
result=pd.concat(rows);ref=pd.read_csv(ROOT/"data/raw/assessments.csv").melt(id_vars=["child_id","wave"],value_vars=list(SCALES)+["numberline_pae"],var_name="outcome",value_name="stored_score")
result=result.merge(ref,on=["child_id","wave","outcome"],validate="one_to_one");result["absolute_difference"]=abs(result.reconstructed_score-result.stored_score)
assert result.absolute_difference.max()<1e-7
write_csv(result,ROOT/"data/derived/item_score_reconciliation.csv")
print(f"Reconciled {len(result):,} scores; max difference {result.absolute_difference.max():.3g}")
