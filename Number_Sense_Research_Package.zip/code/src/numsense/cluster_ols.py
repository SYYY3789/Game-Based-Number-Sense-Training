"""OLS with CR1 cluster-sandwich covariance."""
import numpy as np
def fit_cluster_ols(y,x,groups):
    y=np.asarray(y);x=np.asarray(x);g=np.asarray(groups);bread=np.linalg.inv(x.T@x);b=bread@x.T@y;r=y-x@b;meat=np.zeros_like(bread)
    keys=np.unique(g)
    for k in keys:
        score=x[g==k].T@r[g==k];meat+=np.outer(score,score)
    correction=len(keys)/(len(keys)-1)*(len(y)-1)/(len(y)-x.shape[1])
    return b,correction*bread@meat@bread
