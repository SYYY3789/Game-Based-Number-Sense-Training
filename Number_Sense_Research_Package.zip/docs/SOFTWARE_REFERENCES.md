# Software references

The tested environment uses SciPy 1.17.0. Current official API references were checked on 2026-10-14. API availability does not establish the validity of a statistical estimand.

- SciPy inverse-Wishart distribution and random variates: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.invwishart.html
- SciPy scalar-function minimization, including bounded L-BFGS-B: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.minimize.html

The model equations, variance-pooling equations and implementation scope are documented locally in MODELS.md, MISSING_DATA.md and the source-module docstrings. No external service is required to run the fitted models.
