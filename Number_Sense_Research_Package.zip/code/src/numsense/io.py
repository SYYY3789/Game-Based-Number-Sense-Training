"""Canonical UTF-8 CSV and JSON IO."""
import json
import pandas as pd
def write_csv(frame, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, float_format="%.17g")
def write_json(value, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False, default=str)+"\n", encoding="utf-8")
def read_csv(path):
    return pd.read_csv(path)
