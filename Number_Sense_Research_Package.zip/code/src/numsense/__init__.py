"""Reproducible synthetic preschool cluster trial analysis."""
__version__ = "1.0.0"
