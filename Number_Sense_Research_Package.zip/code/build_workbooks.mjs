import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const root=process.argv[2];
if(!root)throw new Error('Usage: node build_workbooks.mjs PACKAGE_ROOT');
const books=JSON.parse(await fs.readFile(path.join(root,'data/derived/workbook_inputs.json'),'utf8'));
const preview=process.env.PREVIEW_DIR || path.join(root,'results/workbook_previews');
await fs.mkdir(preview,{recursive:true});
function colName(i){let s='';for(i++;i;i=Math.floor((i-1)/26))s=String.fromCharCode(65+(i-1)%26)+s;return s;}
for(const [bi,b] of books.entries()){
  if(process.env.BOOK_NUMBER && bi+1!==Number(process.env.BOOK_NUMBER))continue;
  const wb=Workbook.create();
  for(const [si,s] of b.sheets.entries()){
    const sh=wb.worksheets.add(s.name),nr=s.rows.length,nc=s.rows[0].length;
    sh.showGridLines=false;
    const range=sh.getRangeByIndexes(0,0,nr,nc);range.values=s.rows;
    range.format.font={name:'Arial',size:10,color:'#22394A'};
    range.format.rowHeight=22;range.format.verticalAlignment='center';
    const header=sh.getRangeByIndexes(0,0,1,nc);
    header.format.fill='#2E526B';header.format.font={name:'Arial',size:10,color:'#FFFFFF'};
    header.format.wrapText=true;header.format.rowHeight=46;header.format.horizontalAlignment='center';
    for(let j=0;j<nc;j++){
      const name=String(s.rows[0][j]),sample=s.rows.slice(1).map(r=>r[j]).filter(x=>x!==null);
      const numeric=sample.length>0&&sample.every(x=>typeof x==='number');
      const maxLen=Math.max(name.length,...sample.slice(0,100).map(x=>String(x).length));
      let width=numeric?Math.max(14,Math.min(22,name.length*.75)):Math.min(58,Math.max(16,maxLen*.9));
      if(name==='file')width=44;
      if(name==='description')width=68;
      if(name.includes('95%')||name==='Conclusion'||name==='Evidence Boundary')width=42;
      const c=sh.getRangeByIndexes(0,j,nr,1);c.format.columnWidth=width;
      if(numeric){c.setNumberFormat(sample.every(Number.isInteger)?'0':'0.000');sh.getRangeByIndexes(1,j,nr-1,1).format.horizontalAlignment='right';}
      else{sh.getRangeByIndexes(1,j,nr-1,1).format.wrapText=true;}
    }
    if(bi===3){sh.getRangeByIndexes(1,0,nr-1,nc).format.rowHeight=s.name==='Dictionary'?44:54;}
    sh.tables.add(`A1:${colName(nc-1)}${nr}`,true,`Book${bi+1}Sheet${si+1}`);
    sh.freezePanes.freezeRows(1);if(nc>8)sh.freezePanes.freezeColumns(1);
    // Source note outside the flat table; blank rows do not form records.
    sh.getCell(nr+2,0).values=[[bi===3&&s.name.startsWith('Reported')?'Source: manuscript table; not a computed synthetic result.':'Source: synthetic generator. See docs/DATA_PROVENANCE.md and docs/SCORING.md.']];
    sh.getRangeByIndexes(nr+2,0,1,Math.min(nc,7)).merge();
    sh.getRangeByIndexes(nr+2,0,1,Math.min(nc,7)).format.wrapText=true;
    sh.getRangeByIndexes(nr+2,0,1,Math.min(nc,7)).format.rowHeight=36;
  }
  wb.recalculate();
  const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#SPILL!',options:{useRegex:true,maxResults:10},maxChars:1500});
  console.log(JSON.stringify({file:b.file,errorScan:errors.ndjson}));
  for(const s of b.sheets){
    const blob=await wb.render({sheetName:s.name,range:`A1:${colName(Math.min(s.rows[0].length,7)-1)}${Math.min(s.rows.length,10)}`,scale:1,format:'png'});
    await fs.writeFile(path.join(preview,`${bi+1}_${s.name}.png`),new Uint8Array(await blob.arrayBuffer()));
  }
  const out=await SpreadsheetFile.exportXlsx(wb);await out.save(path.join(root,'data/excel',b.file));
  console.log(JSON.stringify({exported:b.file,sheets:b.sheets.length}));
}
