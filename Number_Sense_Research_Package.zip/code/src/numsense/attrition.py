"""Baseline-dependent attrition with manuscript-matched visit counts."""
import numpy as np
from .constants import ARMS,POST,FOLLOW
def visit_flags(children,rng):
    flags={}
    for arm,npost,nfollow in zip(ARMS,POST,FOLLOW):
        sub=children[children.arm==arm]
        risk=np.exp(-.15*(sub.age_months-sub.age_months.mean())/sub.age_months.std())
        order=rng.choice(sub.index.to_numpy(),len(sub),replace=False,p=risk/risk.sum())
        lostpost=set(order[:len(sub)-npost]);lostfollow=set(order[:len(sub)-nfollow])
        for i in sub.index:flags[children.loc[i,"child_id"]]=(i not in lostpost,i not in lostfollow)
    return flags
