# Data provenance

The supplied manuscript is the design and summary-statistic source. Its ten tables are extracted literally into numbered CSV files with a separate registry. Original personal or institutional records were not supplied. The reference code archive concerns resume/job matching and contains no relevant trial data.

The generator uses NumPy PCG64 with seed 20261014. Class labels are randomly assigned with ten classes in each arm. Synthetic class sizes match totals of 200, 195 and 199. Child ability combines a class component and an individual component. Outcomes share ability and scale-specific persistent factors; item-level realizations add measurement noise. Manuscript means are probability-calibration targets, not sample constraints. Measurement variances, correlations and regression estimates therefore differ from reported values.

All participant identifiers are generated codes. No real identities, consent forms, teacher records, institutional names or source URLs are invented. `SYNTHETIC` flags are included in raw records. Complete pre-attrition outcomes are isolated under `data/simulation_truth/`; estimators read `data/raw/` only.

Posttest and follow-up completion counts are imposed to match the manuscript. Selection is baseline-age dependent and monotone. Follow-up completers are a subset of posttest completers. PP counts are also imposed through attendance generation. This conditioning is useful for software demonstration but cannot validate the original missingness or adherence mechanisms.
