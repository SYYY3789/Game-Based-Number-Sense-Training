"""Available-case secondary outcomes with outcome-specific baseline adjustment."""
import numpy as np
import pandas as pd
from .constants import OUTCOMES
from .design import matrix,contrast
from .mixed_model import fit_mixed
from .inference import estimate,bh,hedges_g
def secondary_effects(frame):
    rows=[];diagnostics=[]
    for outcome in OUTCOMES[1:]+["far_transfer_sum","number_sense_z"]:
        base=frame[frame.wave=="Pretest"].set_index("child_id")[outcome]
        d=frame[(frame.wave!="Pretest")&frame[outcome].notna()].copy();d["baseline_outcome"]=d.child_id.map(base)
        x,names=matrix(d,baseline="baseline_outcome");f=fit_mixed(d[outcome],x,d.class_id,d.child_id)
        diagnostics.append(dict(outcome=outcome,converged=f.converged,class_variance=f.variances[0],child_variance=f.variances[1],residual_variance=f.variances[2]))
        for wave in ["Posttest","Followup"]:
            for comparison in ["G_vs_C","S_vs_C","G_vs_S"]:
                r=estimate(f.beta,f.covariance,contrast(names,comparison,wave));r.update(outcome=outcome,wave=wave,comparison=comparison,analysis="available-case REML")
                a,b={"G_vs_C":("Gamification","Conventional"),"S_vs_C":("Structured","Conventional"),"G_vs_S":("Gamification","Structured")}[comparison]
                aa=frame[(frame.wave=="Pretest")&(frame.arm==a)][outcome];bb=frame[(frame.wave=="Pretest")&(frame.arm==b)][outcome]
                sd=np.sqrt(((len(aa)-1)*aa.var()+(len(bb)-1)*bb.var())/(len(aa)+len(bb)-2))
                r["hedges_g"]=hedges_g(r["estimate"],sd,len(aa),len(bb));r["favorable_g"]=r["hedges_g"]*(-1 if outcome=="numberline_pae" else 1);rows.append(r)
    out=pd.DataFrame(rows);out["q_value"]=out.groupby(["wave","comparison"]).p_value.transform(lambda s:bh(s.to_numpy()))
    return out,pd.DataFrame(diagnostics)
