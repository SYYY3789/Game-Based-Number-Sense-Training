# Excel workbooks

Four workbooks separate participant structure, assessment items, intervention records and reference documentation. Raw tables use a single header row, typed numeric values, frozen identifiers and visible missing-value blanks. All substantive columns and labels are English.

1. `01_Participants_and_Visits.xlsx`: classes, child baseline covariates and planned/observed visits.
2. `02_Assessments_and_Items.xlsx`: assessment scores and all thirteen item-level domain tables, including number-line targets and estimates.
3. `03_Implementation_and_Ratings.xlsx`: intervention attendance, class-session fidelity, dual-observer ratings and manipulation checks.
4. `04_Dictionary_and_Reported_Tables.xlsx`: field dictionary, scoring rules, file-level provenance and the ten literal manuscript tables.

These are static data workbooks. Advanced estimation is performed by the Python modules. Raw values are not overwritten by formulas or adjusted to agree with the paper. Missing visits remain blank. The dictionary documents which files and columns share identifiers and which fields are generated assumptions. For portable imports, use the CSV counterparts with matching English filenames.

To rebuild snapshots in an environment with the documented @oai/artifact-tool authoring dependency, run `python code/prepare_workbooks.py`, then `node --max-old-space-size=8192 code/build_workbooks.mjs /absolute/path/to/Number_Sense_Research_Package`. Set `BOOK_NUMBER` to 1, 2, 3 or 4 to export one workbook per process and keep peak memory bounded. The item workbook contains all raw item responses and therefore requires substantially more memory than running the statistical analysis. Spreadsheet readers do not require this authoring dependency.
