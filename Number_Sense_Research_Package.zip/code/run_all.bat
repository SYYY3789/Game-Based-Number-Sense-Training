@echo off
cd /d "%~dp0\.."
python code\run.py --extended
if errorlevel 1 exit /b 1
python -m unittest discover -s code\tests -v
