"""Study dimensions and explicitly assumed scoring rules."""
ARMS = ["Gamification", "Structured", "Conventional"]
WAVES = ["Pretest", "Posttest", "Followup"]
SIZES = [200, 195, 199]
POST = [188, 185, 191]
FOLLOW = [180, 178, 185]
PP = [176, 174, 185]
# Item counts follow Table 3 where stated. Item maxima and the math item
# count are assumptions because the manuscript supplies no scoring manual.
SCALES = {
    "math": (30, 0, 3, "sum"),
    "counting": (8, 0, 2, "sum"),
    "mapping": (8, 0, 2, "sum"),
    "magnitude": (8, 0, 2, "sum"),
    "composition": (7, 0, 2, "sum"),
    "arithmetic": (6, 0, 2, "sum"),
    "pattern": (8, 0, 1, "sum"),
    "measurement": (8, 0, 1, "sum"),
    "spatial": (8, 0, 1, "sum"),
    "behavioral": (10, 1, 5, "mean"),
    "emotional": (8, 1, 5, "mean"),
    "cognitive": (7, 1, 5, "mean")
}
OUTCOMES = list(SCALES) + ["numberline_pae"]
MEDIATORS = ["behavioral", "emotional", "cognitive"]
NEAR = ["counting", "mapping", "magnitude", "composition", "arithmetic", "numberline_pae"]
TRANSFER = ["pattern", "measurement", "spatial"]
MEANS = {
 "math": [[42.56,52.38,50.15],[42.18,48.65,46.82],[42.35,44.72,44.15]],
 "counting": [[8.45,10.23,9.98],[8.38,9.45,9.22],[8.41,8.95,8.82]],
 "mapping": [[6.78,8.56,8.25],[6.72,7.85,7.58],[6.75,7.12,7.02]],
 "magnitude": [[7.23,9.05,8.78],[7.18,8.32,8.08],[7.20,7.65,7.52]],
 "numberline_pae": [[18.45,12.78,13.52],[18.72,15.23,15.85],[18.58,17.12,17.45]],
 "composition": [[5.67,7.45,7.18],[5.62,6.58,6.35],[5.65,5.98,5.88]],
 "arithmetic": [[4.32,5.85,5.62],[4.28,5.12,4.95],[4.30,4.58,4.50]],
 "pattern": [[3.45,4.12,4.02],[3.42,3.78,3.70],[3.44,3.58,3.52]],
 "measurement": [[3.22,3.78,3.68],[3.18,3.45,3.38],[3.20,3.32,3.28]],
 "spatial": [[3.44,3.98,3.90],[3.41,3.65,3.58],[3.43,3.55,3.50]],
 "behavioral": [[3.65,4.25,4.08],[3.62,3.85,3.78],[3.64,3.72,3.68]],
 "emotional": [[3.42,4.08,3.92],[3.38,3.65,3.58],[3.40,3.48,3.45]],
 "cognitive": [[3.15,3.78,3.65],[3.12,3.38,3.32],[3.14,3.22,3.18]]
}
SD = dict(zip(OUTCOMES,[12.5,2.2,1.9,2.1,1.8,1.7,1.4,1.3,1.3,.64,.70,.76,6.4]))
