"""Numerical tests against independent identities, not stored estimates."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
import unittest
import numpy as np
from numpy.testing import assert_allclose
from numsense.inference import bh,rubin,estimate
from numsense.mixed_model import fit_mixed
from numsense.cluster_ols import fit_cluster_ols
from numsense.reliability import alpha,icc_agreement
from numsense.scoring import pae,score_items
class StatisticsTests(unittest.TestCase):
    def test_bh_known_example(self):assert_allclose(bh([.01,.04,.03,.002]),[.02,.04,.04,.008])
    def test_bh_order_invariance(self):assert_allclose(bh([.4,.01,.02])[::-1],bh([.02,.01,.4]))
    def test_rubin_total_variance(self):
        out=rubin([1,2,3],[4,4,4]);self.assertAlmostEqual(out["se"]**2,4+4/3)
    def test_rubin_no_between_variance(self):self.assertAlmostEqual(rubin([2,2,2],[1,1,1])["se"],1)
    def test_contrast_sign(self):
        a=estimate(np.array([2.,4.]),np.eye(2),np.array([1.,-1.]));self.assertEqual(a["estimate"],-2.)
    def test_alpha_identical_items(self):
        x=np.tile(np.arange(8)[:,None],(1,4));self.assertAlmostEqual(alpha(x),1)
    def test_icc_perfect_agreement(self):self.assertAlmostEqual(icc_agreement(np.tile(np.arange(8)[:,None],(1,2))),1)
    def test_pae_units(self):assert_allclose(pae(np.array([0,10,20]),np.array([[2,12,18]])),10)
    def test_sum_scoring(self):assert_allclose(score_items(np.array([[1,2,1]]),"counting"),4)
    def test_mean_scoring(self):assert_allclose(score_items(np.array([[1,2,3]]),"behavioral"),2)
    def test_mixed_gls_identity(self):
        rng=np.random.default_rng(12);classes=np.repeat(np.arange(8),10);ids=np.repeat(np.arange(40),2)
        x=np.column_stack([np.ones(80),rng.normal(size=80)]);y=x@np.array([3,2])+rng.normal(size=8)[classes]+rng.normal(size=40)[ids]+rng.normal(size=80)
        f=fit_mixed(y,x,classes,ids);self.assertTrue(f.converged)
        v=f.variances[0]*np.equal.outer(classes,classes)+f.variances[1]*np.equal.outer(ids,ids)+f.variances[2]*np.eye(80)
        ref=np.linalg.solve(x.T@np.linalg.solve(v,x),x.T@np.linalg.solve(v,y));assert_allclose(f.beta,ref,rtol=1e-8)
    def test_mixed_rank_rejection(self):
        with self.assertRaises(ValueError):fit_mixed(np.arange(8),np.ones((8,2)),np.repeat([0,1],4),np.arange(8))
    def test_cluster_ols_matches_least_squares(self):
        rng=np.random.default_rng(8);x=np.column_stack([np.ones(60),rng.normal(size=60)]);y=rng.normal(size=60);b,c=fit_cluster_ols(y,x,np.repeat(np.arange(6),10));assert_allclose(b,np.linalg.lstsq(x,y,rcond=None)[0]);self.assertTrue(np.linalg.eigvalsh(c).min()>0)
if __name__=="__main__":unittest.main()
