# Validation report

- Full default configuration with extended delta sensitivity completed successfully.
- Primary, secondary, moderation and standard sensitivity model convergence checks passed.
- 21 unit and integration tests passed.
- 22,113 observed scale scores reconstructed from raw item records. Maximum absolute discrepancy: 1.42e-14.
- A separate working-directory copy reran the complete statistical pipeline. All 26 CSV result tables matched at numerical tolerance 1e-10.
- All ten PNG figures decoded successfully and were visually reviewed. The power-panel decimal comparison was corrected to use numerical tolerance.
- All authored text and tabular data were scanned for non-English CJK text; no matches were found.

- All four Excel workbooks and 34 sheets passed export checks. A total of 519,869 cells reconciled with canonical typed input matrices.
- Every worksheet preview was visually reviewed.

These checks establish software and synthetic-data consistency, not agreement with the original empirical study.
