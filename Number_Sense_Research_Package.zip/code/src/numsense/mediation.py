"""Exploratory parallel mediation at the randomization-unit level.

Uses equal-weight class means, all three mediators jointly and baseline
covariates. Resamples classes within arms. This is an aggregate mediation
analysis, not a participant-level multilevel SEM or a causal mediation claim.
"""
import numpy as np
import pandas as pd
from .constants import MEDIATORS
def paths(d):
    t=(d.arm=="Gamification").astype(float).to_numpy()
    controls=d[["baseline_math","age_months","vocabulary"]].to_numpy();controls-=controls.mean(axis=0)
    x=np.column_stack([np.ones(len(d)),t,controls]);m=d[MEDIATORS].to_numpy();y=d.math.to_numpy()
    a=np.linalg.lstsq(x,m,rcond=None)[0][1];total=np.linalg.lstsq(x,y,rcond=None)[0][1]
    coef=np.linalg.lstsq(np.column_stack([x,m]),y,rcond=None)[0];b=coef[-3:];ind=a*b
    return np.r_[a,b,ind,ind.sum(),coef[1],total]
def mediation(frame,reps,seed):
    d=frame[(frame.wave=="Posttest")&frame.math.notna()].groupby(["class_id","arm"],as_index=False)[["math","baseline_math","age_months","vocabulary"]+MEDIATORS].mean()
    labels=["a_"+x for x in MEDIATORS]+["b_"+x for x in MEDIATORS]+["indirect_"+x for x in MEDIATORS]+["total_indirect","direct","total"]
    rows=[];draws=[];rng=np.random.default_rng(seed)
    for control in ["Conventional","Structured"]:
        pair=d[d.arm.isin(["Gamification",control])].copy();p=paths(pair);boot=[]
        for b in range(reps):
            sampled=pd.concat([g.iloc[rng.integers(0,len(g),len(g))] for _,g in pair.groupby("arm")],ignore_index=True)
            boot.append(paths(sampled))
        boot=np.asarray(boot)
        for j,label in enumerate(labels):
            rows.append(dict(comparison="G_vs_"+("C" if control=="Conventional" else "S"),path=label,estimate=p[j],bootstrap_se=boot[:,j].std(ddof=1),lower=np.quantile(boot[:,j],.025),upper=np.quantile(boot[:,j],.975),replicates=reps,method="class-mean parallel mediation"))
        for b,row in enumerate(boot):draws.append(dict(comparison=control,replicate=b+1,**dict(zip(labels,row))))
    return pd.DataFrame(rows),pd.DataFrame(draws)
