"""Integration tests for scoring, missingness and MI observation preservation."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
import unittest
import numpy as np
import pandas as pd
from numpy.testing import assert_allclose
from numsense.paths import ROOT
from numsense.constants import SCALES
from numsense.scoring import score_items,pae
from numsense.design import analysis_frame
from numsense.imputation import impute_primary
from numsense.validation import validate
class DataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.children=pd.read_csv(ROOT/"data/raw/children.csv");cls.panel=pd.read_csv(ROOT/"data/raw/assessments.csv")
    def test_design_contract(self):
        checks=validate(self.children,self.panel,pd.read_csv(ROOT/"data/raw/classes.csv"),pd.read_csv(ROOT/"data/raw/attendance.csv"));self.assertTrue(all(c["passed"] for c in checks))
    def test_all_item_scales_reconstruct(self):
        for scale in SCALES:
            with self.subTest(scale=scale):
                d=pd.read_csv(ROOT/f"data/raw/items_{scale}.csv");merged=d.merge(self.panel[["child_id","wave",scale]],on=["child_id","wave"],validate="one_to_one")
                observed=merged.observed==1;x=merged.loc[observed].filter(regex="^item_").to_numpy();assert_allclose(score_items(x,scale),merged.loc[observed,scale],rtol=1e-8)
    def test_numberline_reconstruct(self):
        d=pd.read_csv(ROOT/"data/raw/items_numberline.csv");m=d.merge(self.panel[["child_id","wave","numberline_pae"]],on=["child_id","wave"]);m=m[m.observed==1]
        assert_allclose(pae(m.filter(regex="^target_").to_numpy(),m.filter(regex="^estimate_").to_numpy()),m.numberline_pae,rtol=1e-8)
    def test_imputation_preserves_observed(self):
        f=analysis_frame(self.children,self.panel);draws,_=impute_primary(f,2,3,1)
        for d in draws:
            a=f.set_index(["child_id","wave"]).math;b=d.set_index(["child_id","wave"]).math;assert_allclose(a.dropna(),b.reindex(a.dropna().index));self.assertTrue(b.notna().all())
    def test_monotone_attrition(self):self.assertTrue((self.children.followup_complete<=self.children.posttest_complete).all())
    def test_no_real_identifiers(self):self.assertTrue(self.children.child_id.str.match(r"C\d{2}_P\d{2}").all())
    def test_simulation_truth_separate(self):
        f=analysis_frame(self.children,self.panel);self.assertTrue(f.loc[f.observed==0,"math"].isna().all())
    def test_imputations_are_distinct(self):
        f=analysis_frame(self.children,self.panel);d,_=impute_primary(f,2,3,12);self.assertFalse(np.allclose(d[0].math,d[1].math))
if __name__=="__main__":unittest.main()
