"""Static HTML report linking computed figures and CSV estimates."""
from html import escape
def write_report(root,primary,checks):
    html='<!doctype html><html lang="en"><meta charset="utf-8"><title>Synthetic Number Sense Trial</title><style>body{font:16px Arial;max-width:1100px;margin:40px auto;padding:20px;color:#24384b}table{border-collapse:collapse;font-size:14px}td,th{padding:8px;border-bottom:1px solid #ddd}img{width:100%}h1,h2{font-weight:500}aside{background:#fff3d6;padding:16px}a{color:#35649c}</style>'
    m=int(primary.m.iloc[0])
    html+=f'<h1>Synthetic Number Sense Trial</h1><aside>All individual records are simulated. These computed estimates demonstrate the analysis workflow and do not verify the manuscript findings.</aside><p>594 children, 30 classes, three arms, three planned visits. Primary analysis: {m} joint-normal imputations and nested random-intercept REML with Rubin pooling. Secondary outcomes use available cases.</p>'
    html+='<h2>Primary effects</h2>'+primary[["wave","comparison","estimate","se","lower","upper","p_value"]].to_html(index=False,float_format=lambda x:f"{x:.4f}")
    html+='<h2>Data validation</h2><p>'+str(sum(x["passed"] for x in checks))+" checks passed.</p>"
    for p in sorted((root/"results/figures").glob("*.png")):html+=f'<h2>{escape(p.stem.replace("_"," "))}</h2><img src="figures/{p.name}" alt="{escape(p.stem)}">'
    html+='<h2>Method boundaries</h2><p>Wald inference uses a cluster-count reference, not Kenward-Roger degrees of freedom. Mediation uses class means and cannot establish causal indirect effects. Imputation and item-scoring assumptions are fully documented in the code and documentation.</p></html>'
    (root/"results/report.html").write_text(html)
