"""Fail early on design, key, range and visit inconsistencies."""
import numpy as np
from .constants import *
def validate(children,panel,classes,attendance):
    checks=[]
    def check(name,ok,detail):
        checks.append(dict(check=name,passed=bool(ok),detail=str(detail)))
        if not ok:raise ValueError(name+": "+str(detail))
    check("Unique child IDs",not children.child_id.duplicated().any(),len(children))
    check("Unique child-wave keys",not panel.duplicated(["child_id","wave"]).any(),len(panel))
    check("Three planned waves",len(panel)==3*len(children),len(panel))
    check("Class assignment consistency",children.groupby("class_id").arm.nunique().max()==1,"one arm per class")
    check("Class foreign keys",set(children.class_id)<=set(classes.class_id),len(classes))
    for arm,n,np_,nf,pp in zip(ARMS,SIZES,POST,FOLLOW,PP):
        c=children[children.arm==arm]
        check(arm+" allocation",len(c)==n,len(c))
        check(arm+" posttest",c.posttest_complete.sum()==np_,c.posttest_complete.sum())
        check(arm+" followup",c.followup_complete.sum()==nf,c.followup_complete.sum())
        check(arm+" PP",c.pp_eligible.sum()==pp,c.pp_eligible.sum())
    check("Missing visits have no observed scores",panel.loc[panel.observed==0,OUTCOMES].isna().all().all(),"all scores blank")
    check("Complete visits have all scores",panel.loc[panel.observed==1,OUTCOMES].notna().all().all(),"no item missingness within visits")
    check("Attendance keys",not attendance.duplicated(["child_id","session"]).any(),len(attendance))
    for k,(n,lo,hi,method) in SCALES.items():
        a,b=(lo,hi) if method=="mean" else (lo*n,hi*n)
        check(k+" range",panel[k].dropna().between(a,b).all(),f"{a} to {b}")
    check("Synthetic status",set(panel.data_status)=={"SYNTHETIC"},"all records")
    return checks
